/**
 * 
 * 
 */
var LayoutFactory  = {
		
		defaultMenu: [
		               { caption: Lang.MENU_HOME[Settings.Language], desc: "Apresentação", href: "/page/index.html" },
		    	       { caption: Lang.MENU_TEMA1[Settings.Language], desc: "Estrutura Demográfica", href: "/layout/tema1" },
		    	       { caption: Lang.MENU_TEMA2[Settings.Language], desc: "Autonomia Econômica", href: "/layout/tema2" },
		    	       { caption: Lang.MENU_TEMA3[Settings.Language], desc: "Educação", href: "/layout/tema3" },
		    	       { caption: Lang.MENU_TEMA4[Settings.Language], desc: "Saúde", href: "/layout/tema4" },
		    	       { caption: Lang.MENU_TEMA5[Settings.Language], desc: "Violência", href: "/layout/tema5" },
		    	       { caption: Lang.MENU_TEMA6[Settings.Language], desc: "Poder e Decisão", href: "/layout/tema6" },
		    	       { caption: Lang.MENU_TEMA7[Settings.Language], desc: "Mecanismos Institucionais", href: "/layout/tema7" },
		    	       { caption: Lang.MENU_CATALOG[Settings.Language], desc: "Informações e download de indicadores", href: "/layout/catalog" }
					]
};